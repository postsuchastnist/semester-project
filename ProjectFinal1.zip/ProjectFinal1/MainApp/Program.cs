﻿using System;
using static  System.Console;


namespace projectfinal;


public class MyProg
{
    public static void Main()
    {
        bool flag = true;
        while (flag) //in this (possibly infinite) loop I write consequences of each input command. I decided not to try hard on it, so 
            // everything is written in this loops and not separated on functions.
        {
            WriteLine("Type the command which you want to execute(add - for matrix addition, mult - for matrix multiplication, inverse - for matrix inverse, det - for matrix determinant, exit - to terminate the programm): ");
            string? s = ReadLine();
            if (s == "exit" || s == "Exit")
            {
                WriteLine("Terminating the program");
                flag = false;
                break;
            }

            if (s == "add" || s == "Add")
            {
                Matrix.Add();
            }

            if (s == "mult" || s == "Mult")
            {
                Matrix.Mult();
            }

            if (s == "inverse" || s == "Inverse")
            {
                Matrix.Inv();
            }

            if (s == "det" || s == "Det")
            {
                Matrix.Det();
            }
        }
    }
}